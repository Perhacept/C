﻿// HitLetterX.cpp : 定义应用程序的入口点。
//

#include "stdafx.h"
#include "HitLetterX.h"

#define MAX_LOADSTRING 100

// 全局变量:
HINSTANCE hInst;                                // 当前实例
WCHAR szTitle[MAX_LOADSTRING];                  // 标题栏文本
WCHAR szWindowClass[MAX_LOADSTRING];            // 主窗口类名

COLORREF color = RGB(255, 0, 0);
int health = 3;
int score = 0;
unsigned long times = 0;
unsigned long times2 = 0;
unsigned long times3 = 0;
unsigned long times4 = 0;
unsigned long timeStep = 3000;
int anJianCiShu = 0;
char c;
char wsdd;
char hit;
WCHAR str[64];
// 此代码模块中包含的函数的前向声明:
ATOM                MyRegisterClass(HINSTANCE hInstance);
BOOL                InitInstance(HINSTANCE, int);
LRESULT CALLBACK    WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK    About(HWND, UINT, WPARAM, LPARAM);

int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
                     _In_opt_ HINSTANCE hPrevInstance,
                     _In_ LPWSTR    lpCmdLine,
                     _In_ int       nCmdShow)
{
    UNREFERENCED_PARAMETER(hPrevInstance);
    UNREFERENCED_PARAMETER(lpCmdLine);

    // TODO: 在此处放置代码。
	c = 'A' + rand() % 26 + (rand() % 2) * 32;
		// || ('a' + (rand() % 26)));
	wsdd = c - 32;
	times = GetTickCount();
	times2 = GetTickCount();
    // 初始化全局字符串
    LoadStringW(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
    LoadStringW(hInstance, IDC_HITLETTERX, szWindowClass, MAX_LOADSTRING);
    MyRegisterClass(hInstance);

    // 执行应用程序初始化:
    if (!InitInstance (hInstance, nCmdShow))
    {
        return FALSE;
    } 

    HACCEL hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_HITLETTERX));

    MSG msg;

    // 主消息循环:
    while (GetMessage(&msg, nullptr, 0, 0))
    {
        if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }

    return (int) msg.wParam;
}



//
//  函数: MyRegisterClass()
//
//  目标: 注册窗口类。
//
ATOM MyRegisterClass(HINSTANCE hInstance)
{
    WNDCLASSEXW wcex;

    wcex.cbSize = sizeof(WNDCLASSEX);

    wcex.style          = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc    = WndProc;
    wcex.cbClsExtra     = 0;
    wcex.cbWndExtra     = 0;
    wcex.hInstance      = hInstance;
    wcex.hIcon          = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_HITLETTERX));
    wcex.hCursor        = LoadCursor(nullptr, IDC_ARROW);
    wcex.hbrBackground  = (HBRUSH)(COLOR_WINDOW+1);
    wcex.lpszMenuName   = MAKEINTRESOURCEW(IDC_HITLETTERX);
    wcex.lpszClassName  = szWindowClass;
    wcex.hIconSm        = LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));

    return RegisterClassExW(&wcex);
}

//
//   函数: InitInstance(HINSTANCE, int)
//
//   目标: 保存实例句柄并创建主窗口
//
//   注释:
//
//        在此函数中，我们在全局变量中保存实例句柄并
//        创建和显示主程序窗口。
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
   hInst = hInstance; // 将实例句柄存储在全局变量中

   HWND hWnd = CreateWindowW(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
      CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, nullptr, nullptr, hInstance, nullptr);

   if (!hWnd)
   {
      return FALSE;
   }

   ShowWindow(hWnd, nCmdShow);
   UpdateWindow(hWnd);

   return TRUE;
}

//
//  函数: WndProc(HWND, UINT, WPARAM, LPARAM)
//
//  目标: 处理主窗口的消息。
//
//  WM_COMMAND  - 处理应用程序菜单
//  WM_PAINT    - 绘制主窗口
//  WM_DESTROY  - 发送退出消息并返回
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
    case WM_COMMAND:
        {
            int wmId = LOWORD(wParam);
            // 分析菜单选择:
            switch (wmId)
            {
            case IDM_ABOUT:
                DialogBox(hInst, MAKEINTRESOURCE(IDD_ABOUTBOX), hWnd, About);
                break;
            case IDM_EXIT:
                DestroyWindow(hWnd);
                break;
            default:
                return DefWindowProc(hWnd, message, wParam, lParam);
            }
        }
        break;
		//HitLetter
		/*
				if (anJianCiShu == 0) {
			times4 = GetTickCount() - times2;
			if (times4 >= 300) {
				health = health - 1;
				times2 = GetTickCount();
			}
		}
		else {
			times2 = GetTickCount() - times3;
			if (times2 >= 300) {
				health = health - 1;
				times3 = GetTickCount();
			}
		}
		*/
	/*case WM_CREATE:
		SetTimer(hWnd, 1, timeStep, NULL);
		break;
	case WM_TIMER:
		if (anJianCiShu == 0) {
			times4 = GetTickCount() - times2;
			if (times4 >= 3000) {
				health = health - 1;
				times2 = GetTickCount();
			}
		}
		else {
			times2 = GetTickCount() - times3;
			if (times2 >= 3000) {
				health = health - 1;
				times3 = GetTickCount();
			}
		}*/
		/*if (anJianCiShu == 0) {
			times4 = GetTickCount() - times2;
			if (times4 >= 300) {
				health = health - 1;
				times2 = GetTickCount();
			}
		}
		else {
			times2 = GetTickCount() - times3;
			if (times2 >= 300) {
				health = health - 1;
				times3 = GetTickCount();
			}
		}*/
	case WM_CREATE:
		SetTimer(hWnd, 1, timeStep, NULL);
		break;
	case WM_TIMER:
		if (wParam == 1)
		{
			if (health > 0)
			{
				health = health - 1;
				InvalidateRect(hWnd, NULL, TRUE);
			}

		}
		break;
	case WM_KEYDOWN:
		//anJianCiShu = anJianCiShu + 1;
		//times3 = GetTickCount();
		if (health <= 0)
			break;
		hit = wParam;
		SetTimer(hWnd, 1, timeStep, NULL);
		if (hit == c)
		{
			c = 'A' + rand() % 26 + (rand() % 2) * 32;
			wsdd = c - 32;
			//c = 'A' + rand() % 26;
			score = score + 1;
		}
		else
		{
			if (hit == wsdd)
			{
				c = 'A' + rand() % 26 + (rand() % 2) * 32;
				wsdd = c - 32;
				score = score + 1;
			}
			else{
			health = health - 1;
			if (health <= 0)
				times = GetTickCount() - times;
			}
		}
		InvalidateRect(hWnd, NULL, TRUE);
		break;
    case WM_PAINT:
		/*void PrintWords(HDC hdc);
		{
			RECT rc;
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hWnd, &ps);
			GetClientRect(hWnd, &rc);
			SetBkMode(hdc, TRANSPARENT);
			HFONT hf;
			SetTextColor(hdc, color);
			hf =
				CreateFont(
					56, 
					20, 
					0, 
					0,
					45,//size
					FALSE, FALSE, FALSE,
					DEFAULT_CHARSET,
					OUT_DEFAULT_PRECIS,
					CLIP_DEFAULT_PRECIS,
					DEFAULT_QUALITY,
					DEFAULT_PITCH,
					L"XinZiTi");
			HFONT hfold = (HFONT)SelectObject(hdc, hf);
		
		}*/


        {
           PAINTSTRUCT ps;
           HDC hdc = BeginPaint(hWnd, &ps);
            // TODO: 在此处添加使用 hdc 的任何绘图代码...
			///HFONT hfold = (HFONT)SelectObject(hdc, hf);
			/*
			if (anJianCiShu == 0) {
				times4 = GetTickCount() - times2;
				if (times4 >= 300) {
					health = health - 1;
					times2 = GetTickCount();
				}
			}
			else {
				times2 = GetTickCount() - times3;
				if (times2 >= 300) {
					health = health - 1;
					times3 = GetTickCount();
				}
			}
			*/
			//
			//SetTextColor(hdc, color);


			/*hf =
				CreateFont(
					56,
					20,
					0,
					0,
					45,//size
					FALSE, FALSE, FALSE,
					DEFAULT_CHARSET,
					OUT_DEFAULT_PRECIS,
					CLIP_DEFAULT_PRECIS,
					DEFAULT_QUALITY,
					DEFAULT_PITCH,
					L"XinZiTi");
			HFONT hfold = (HFONT)SelectObject(hdc, hf);
			*/
		   HFONT haoZiTi;
		   haoZiTi =
			   CreateFont(
				   11,//height
				   12,//width
				   0,//zitijiaoduAngle
				   0,//fangxiang?
				   1,//size
				   FALSE, FALSE, FALSE,//斜体，下划线，删除线
				   DEFAULT_CHARSET,
				   OUT_DEFAULT_PRECIS,
				   CLIP_DEFAULT_PRECIS,
				   DEFAULT_QUALITY,
				   DEFAULT_PITCH,
				   L"XinZiTi");
		   HFONT hfold = (HFONT)SelectObject(hdc, haoZiTi);
			//HFONT//
			SetTextColor(hdc, color);
			TextOut(hdc, 0, 0, L"请输入正确字母!", 9);
			swprintf(str, 64, L"生命数：%d", health);
			TextOut(hdc, 200, 0, str, wcslen(str));
			TextOut(hdc, 550, 0, L"times2:%d", times2);

			swprintf(str, 64, L"得分：%d", score);
			TextOut(hdc, 400, 0, str, wcslen(str));
			if (health <= 0)
			{
				swprintf(str,64, L"游戏结束，打字速度：%.2f个每秒",
					float(score * 1000) / times);

			}
			else
				swprintf(str,64, L"%c", c);
				TextOut(hdc, 20, 40, str, wcslen(str));//
            EndPaint(hWnd, &ps);
        }
        break;
    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    default:
        return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}

// “关于”框的消息处理程序。
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    UNREFERENCED_PARAMETER(lParam);
    switch (message)
    {
    case WM_INITDIALOG:
        return (INT_PTR)TRUE;

    case WM_COMMAND:
        if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
        {
            EndDialog(hDlg, LOWORD(wParam));
            return (INT_PTR)TRUE;
        }
        break;
    }
    return (INT_PTR)FALSE;
}
